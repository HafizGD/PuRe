-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2025 at 05:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news_system`
--
CREATE DATABASE IF NOT EXISTS `news_system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `news_system`;

-- --------------------------------------------------------

--
-- Table structure for table `bookmarks_news`
--

DROP TABLE IF EXISTS `bookmarks_news`;
CREATE TABLE `bookmarks_news` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `link` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookmarks_news`
--

INSERT INTO `bookmarks_news` (`id`, `user_id`, `link`, `created_at`) VALUES
(1, 1, 'https://news.com/politik/berita-1', '2025-11-15 23:29:54'),
(2, 2, 'https://news.com/teknologi/berita-2', '2025-11-15 23:29:54'),
(3, 2, 'https://update.com/berita/update-3', '2025-11-15 23:29:54'),
(4, 3, 'https://news.com/hoax/berita-3', '2025-11-15 23:29:54');

-- --------------------------------------------------------

--
-- Table structure for table `recent_news`
--

DROP TABLE IF EXISTS `recent_news`;
CREATE TABLE `recent_news` (
  `id` int(11) NOT NULL,
  `link` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recent_news`
--

INSERT INTO `recent_news` (`id`, `link`, `created_at`) VALUES
(1, 'https://update.com/berita/update-1', '2025-11-15 23:29:54'),
(2, 'https://update.com/berita/update-2', '2025-11-15 23:29:54'),
(3, 'https://update.com/berita/update-3', '2025-11-15 23:29:54');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password_hash`, `created_at`) VALUES
(1, 'admin', 'hashed_password_123', '2025-11-15 23:29:54'),
(2, 'fawwaz', 'hashed_password_456', '2025-11-15 23:29:54'),
(3, 'guest', 'hashed_password_789', '2025-11-15 23:29:54');

-- --------------------------------------------------------

--
-- Table structure for table `validate_news`
--

DROP TABLE IF EXISTS `validate_news`;
CREATE TABLE `validate_news` (
  `id` int(11) NOT NULL,
  `link` text DEFAULT NULL,
  `jumlah_valid` int(11) DEFAULT 0,
  `jumlah_tidak_valid` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `validate_news`
--

INSERT INTO `validate_news` (`id`, `link`, `jumlah_valid`, `jumlah_tidak_valid`, `created_at`) VALUES
(1, 'https://news.com/politik/berita-1', 12, 3, '2025-11-15 23:29:54'),
(2, 'https://news.com/teknologi/berita-2', 25, 1, '2025-11-15 23:29:54'),
(3, 'https://news.com/hoax/berita-3', 3, 18, '2025-11-15 23:29:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookmarks_news`
--
ALTER TABLE `bookmarks_news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `recent_news`
--
ALTER TABLE `recent_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `validate_news`
--
ALTER TABLE `validate_news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookmarks_news`
--
ALTER TABLE `bookmarks_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `recent_news`
--
ALTER TABLE `recent_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `validate_news`
--
ALTER TABLE `validate_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookmarks_news`
--
ALTER TABLE `bookmarks_news`
  ADD CONSTRAINT `bookmarks_news_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
